#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include <unistd.h>

void check_sum(char *buffer, int buffer_size);
char add(char num1, char num2);
char sum;

int main(int argc, char* argv[])
{
	FILE *file;
	char *buffer;
	unsigned long fileLen;

	if(argc != 2) 
	{
	    fprintf(stderr, "Usage: %s <fileName> \n", argv[0]);
	    return 1;
  	}

  	file = fopen(argv[1], "rb");
  	if (!file)
	{
		fprintf(stderr, "Unable to open file %s", argv[1]);
		return 0;
	}
	fseek(file, 0, SEEK_END);
	fileLen=ftell(file);
	fseek(file, 0, SEEK_SET);

	buffer=(char *)malloc(fileLen+1);
	if (!buffer)
	{
		fprintf(stderr, "Error locating memory!");
        fclose(file);
		return 0;
	}

	fread(buffer, fileLen, 1, file);
	fclose(file);
	check_sum(buffer, fileLen);
	free(buffer);
	return 1;
}

void check_sum(char *buffer, int buffer_size)
{
	char num1 = 0;
	char num2 = 0;
	int i;
	num1 = ((char *)buffer)[0];
	for(i = 1; i < buffer_size; i++)
	{
		num2 = ((char *)buffer)[i];
		num1 = add(num1, num2);
		sum = num1;
	}
	sum = ~sum;
	printf("Checksum: %#x\n", (unsigned char)sum);
}

char add(char num1, char num2)
{
	char temp = 0x00;
	temp = num1 + num2;
	if(((num1 & 0x80) == 0x80) && ((num2 & 0x80) == 0x80))
	{
		temp += 0x01;
		return temp;
	}
	if(((num1 & 0x80) == 0x00) && ((num2 & 0x80) == 0x00))
	{
		return temp;
		//do nothing
	}else{
		if((temp & 0x80) == 0x00)
		{
			temp += 0x01;
			return temp;
		}
	}
   return temp;
}